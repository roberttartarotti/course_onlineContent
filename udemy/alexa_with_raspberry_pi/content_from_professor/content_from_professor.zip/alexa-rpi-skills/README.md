# Building Alexa Skills for Home Automation with Raspberry Pi

This repository contains the code for the projects that are taught in the online course
Building Alexa Skills for Home Automation with Raspberry Pi
