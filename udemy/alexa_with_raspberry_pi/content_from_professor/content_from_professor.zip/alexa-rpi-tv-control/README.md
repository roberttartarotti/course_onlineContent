# Create a custom alexa skill in python to control your tv with voice using a raspberry pi

In this project, I utilize the flask-ask python library and LIRC (Linux Infrared Control) library to create a Custom Alexa Skill that you can use to voice control any tv with a Raspberry Pi.

